#!/bin/sh
find "dtv_linux" -follow -lname '*' -prune -o -iname '*.[CH]' -print > cscope.files
find "dtv_linux" -follow -lname '*' -prune -o -name '*.cpp' -print  >> cscope.files
find "android/jb-4.x/device/Philips/TPV" -follow -lname '*' -prune -o -iname '*.[CH]' -print >> cscope.files
find "android/jb-4.x/device/Philips/TPV" -follow -lname '*' -prune -o -name '*.cpp' -print  >> cscope.files
find "chiling/kernel/linux-3.4" -follow -lname '*' -prune -o -iname '*.[CH]' -print >> cscope.files
find "chiling/kernel/linux-3.4" -follow -lname '*' -prune -o -name '*.cpp' -print  >> cscope.files
find "project_x" -follow -lname '*' -prune -o -iname '*.[CH]' -print >> cscope.files
find "project_x" -follow -lname '*' -prune -o -name '*.cpp' -print  >> cscope.files


# -b: just build
# -q: create inverted index
cscope -b -q
ctags -R --languages=C,C++ --c++-kinds=+p --fields=+iaS --extra=+q ./
gtags -f cscope.files
#ctags -R --lang=c --lang=c++ --c++-kinds=+p --fields=+iaS --extra=+q ./
