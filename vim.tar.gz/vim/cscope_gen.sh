#!/bin/sh
find "$PWD" -iname '*.[CH]' \
-o -name '*.cpp' \
-o -name '*.cc' \
-o -name '*.hpp' -print  \
> cscope.files

# -b: just build
# -q: create inverted index
cscope -b -q
ctags -R --languages=C,C++ --c++-kinds=+p --fields=+iaS --extra=+q ./
