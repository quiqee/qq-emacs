#!/bin/sh
if [[ -z "$1" ]]
  then
  echo "Please enter the directory to scan."
  exit 1
fi
rm -f cscope.files cscope.files.bak cscope.in.out cscope.out cscope.po.out GPATH GRTAGS GTAGS

echo "Scanning folders for C/C++ files..."
find "philips_eu_l_pq" ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' > cscope.files
find "$1"/device/common ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/device/generic/arm64 ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/device/generic/armv7-a-neon ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/frameworks/opt ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/frameworks ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/hardware ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/libcore ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/libnativehelper ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/device/tpvision/common/plf ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/device/tpvision/tv ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/vendor/tv ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/device/mediatek_common/vm_linux ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/device/tpvision/tvsoc ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files
find "$1"/device/tpvision/mtk_common ! -type l -and -type f | grep '\.h$\|\.cpp$\|\.c$' | sed 's/\(.*\)/\"\1\"/g' >> cscope.files

# -b: just build
# -q: create inverted index
echo "Generating cscope database..."
cscope -b -q
#/usr/bin/ctags -R --languages=C,C++ --c++-kinds=+p --fields=+iaS --extra=+q ./
perl -lpe 's/^"|"$//g' < cscope.files > gtags.files
echo "Generating gtags database..."
gtags -f gtags.files
rm gtags.files
#ctags -R --lang=c --lang=c++ --c++-kinds=+p --fields=+iaS --extra=+q ./

