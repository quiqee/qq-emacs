#!/bin/sh
find "dtv_linux" -type f \( -iname '*.[CH]' ! -type l \) -print > cscope.files
find "dtv_linux" -type f \( -name '*.cpp' ! -type l \) -print  >> cscope.files
find "third_party" -type f \( -iname '*.[CH]' ! -type l \) -print >> cscope.files
find "third_party" -type f \( -name '*.cpp' ! -type l \) -print  >> cscope.files
find "chiling/kernel/linux-3.0" -type f \( -iname '*.[CH]' ! -type l \) -print >> cscope.files
find "chiling/driver" -type f \( -iname '*.[CH]' ! -type l \) -print >> cscope.files
find "chiling/app_if" -type f \( -iname '*.[CH]' ! -type l \) -print >> cscope.files
find "chiling/app_if" -type f \( -name '*.cpp' ! -type l \) -print  >> cscope.files
find "project_x" -type f \( -iname '*.[CH]' ! -type l \) -print >> cscope.files
find "project_x" -type f \( -name '*.cpp' ! -type l \) -print  >> cscope.files


# -b: just build
# -q: create inverted index
cscope -b -q
#ctags -R --languages=C,C++ --c++-kinds=+p --fields=+iaS --extra=+q ./
gtags -f cscope.files
#ctags -R --lang=c --lang=c++ --c++-kinds=+p --fields=+iaS --extra=+q ./
