To execute neobundle test:

  cd # {neobundle.vim path}
  vim -u test/vimrc -U NONE --noplugin
