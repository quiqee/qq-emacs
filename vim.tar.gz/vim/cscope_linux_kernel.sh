#!/bin/sh
find "$PWD"                                                                 \
    -path "$PWD/arch/*" ! -path "$PWD/arch/i386*" -prune -o                 \
    -path "$PWD/include/asm-*" ! -path "$PWD/include/asm-i386*" -prune -o   \
    -path "$PWD/tmp*" -prune -o                                             \
    -path "$PWD/Documentation*" -prune -o                                   \
    -path "$PWD/scripts*" -prune -o                                         \
    -path "*.[chxsS]" -print                                                \
    > cscope.files

# -b: just build
# -q: create inverted index for faster search on large database
# -k: kernel mode
cscope -b -q -k
ctags -R --languages=C --c++-kinds=+p --fields=+iaS --extra=+q ./
